import React from 'react';

export default function ConsultaStock() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Consulta de Stock</h2>
      <p>Aquí mostrarás la tabla de stock próximamente.</p>
    </div>
  );
}

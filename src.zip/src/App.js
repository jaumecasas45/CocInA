import React from 'react';
import AlbaranUploader from './AlbaranUploader';

function App() {
  return (
    <div className="App">
      <AlbaranUploader />
    </div>
  );
}

export default App;
